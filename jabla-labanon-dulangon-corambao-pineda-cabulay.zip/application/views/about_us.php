<center>
	<div style="margin-top: 5%;">
	<h4> About Us </h4>
		<img height="150px" style="margin-right: 5%;" src="<?php echo base_url();?>assets/images/owner.png">
		<img height="150px" src="<?php echo base_url();?>assets/images/owner.png">
		<img height="150px" style="margin-left: 5%;" src="<?php echo base_url();?>assets/images/owner.png">
	</div>
</center>