<div class="container">

    <div id="carouselContent" class="carousel slide" data-ride="carousel">
  
        <div class="carousel-inner" role="listbox">
                <div class="zoom">
            <div class="carousel-item active text-center p-4">
                 <a href="#">2005</a>
                 <a href="#">2006</a>
                 <a href="#">2007</a>
                 <a href="#">2008</a>
                 <a href="#">2009</a>
            </div>
            <div class="carousel-item text-center p-4">
                
               <a href="#">2010</a>
               <a href="#">2011</a>
               <a href="#">2012</a>
               <a href="#">2013</a>
               <a href="#">2014</a>

            </div>
            <div class="carousel-item text-center p-4">
                 <a href="#">2015</a>
                 <a href="#">2016</a>
                 <a href="#">2017</a>
                 <a href="#">2018</a>
                 <a href="#">2019</a>

            </div>
            <div class="carousel-item text-center p-4">
                 <a href="#">2020</a>
                 <a href="#">2021</a>
                 <a href="#">2022</a>
               </div>
               
</div>

        </div>

       <a class="carousel-control-prev" href="#carouselContent" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon"><img src="<?php echo base_url(); ?>assets/images/left.png" width="20px" height="20px"/></span>
            <span class="sr-only">Previous</span>
          
        </a>
        <a class="carousel-control-next" href="#carouselContent" role="button" data-slide="next">
            <span class="carousel-control-next-icon"><img src="<?php echo base_url(); ?>assets/images/RIGHT.png" width="20px" height="20px"/></span>
            <span class="sr-only">Next</span>
        </a>

</div>



<br>
<div>
<img style="float: left; margin: 0px 15px 15px 0px;" src="<?php echo base_url(); ?>assets/images/S1.png" />
<span style=""><h4>Coffee</h4><br>Complex, sweetly tart, spice-toned. Peach, fine musk, toffee, macadamia nut, roasted cacao nib in aroma and cup. Sweet-tart structure with vibrant, juicy acidity; plush, syrupy mouthfeel. The elegant, lingering finish centers around notes of peach, toffee and fine musk, all cocoa-toned.
</span>
</div>
<br><br><br><br><br>
<div>
<img style="float: left; margin: 0px 15px 15px 0px;" src="<?php echo base_url(); ?>assets/images/S2.png" />
<span style=""><h4>Coffee</h4><br>Complexly layered with sweet-savory depth. Wisteria, hop flowers, candied grapefruit zest, black cherry, pistachio butter in aroma and cup. Sweetly savory structure with gentle, rounded acidity; viscous, syrupy mouthfeel. The flavor-saturated finish is a mirror of the cup, carrying through on the coffee’s savory-sweet resonance.
</span>
</div>



<br><br><br><br><br>
<div>
<img style="float: left; margin: 0px 15px 15px 0px;" src="<?php echo base_url(); ?>assets/images/S3.png" />
<span style=""><h4>Coffee</h4><br>Aromatically subtle, sweetly tart. Pie cherry, roasted cacao nib, pistachio, thyme, freesia-like flowers in aroma and cup. Sweetly tart structure with juicy, vibrant acidity; viscous, syrupy acidity. The finish consolidates to notes of cocoa-toned pie cherry and freesia.
</span>
</div>


<br><br><br><br><br>
<div>
<img style="float: left; margin: 0px 15px 15px 0px;" src="<?php echo base_url(); ?>assets/images/S4.png" />
<span style=""><h4>Coffee</h4><br>Delicate, crisply fruit-toned. Concord grape, almond nougat, honeysuckle, bay leaf, roasted cacao nib in aroma and cup. Sweet-tart structure with rounded acidity; full, syrupy mouthfeel. Notes of Concord grape take center stage in the finish, supported by sweet floral and nut tones.
</span>
</div>
          